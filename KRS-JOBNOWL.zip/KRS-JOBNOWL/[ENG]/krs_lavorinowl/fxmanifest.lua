fx_version 'cerulean'
game 'gta5'
lua54 'yes'

Nome 'krs'
Autore '𝗞𝗥𝗦®'
Discord 'https://discord.gg/wM4XDaXfU8' -- 𝗞𝗥𝗦® --


client_script {
    'config.lua',
    'client.lua'
}

server_script {
    'config.lua',
    'server.lua'
}

shared_scripts  {
    "@ox_lib/init.lua",
    "@es_extended/imports.lua",
}

ui_page 'lavoro.html'

files{

    'lavoro.html',
    'lavoro.css',
    'lavoro.js',
    'boscaiolo.png',
    'minatore.png',
    'lattaio.png',
    'agricoltore.png',
}