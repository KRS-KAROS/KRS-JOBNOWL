const playerLavoro = document.querySelector("#sceltalavoro");

function apriSceltaLavoro() {
 
  document.querySelector(".titolo").style.display = "block";
  document.querySelector(".lavoro").style.display = "block";
  document.querySelector(".lavoro2").style.display = "block";
  document.querySelector(".lavoro3").style.display = "block";
  document.querySelector(".lavoro4").style.display = "block";
  document.querySelector(".lavoro5").style.display = "block";
  document.querySelector(".bg").style.display = "block";
}

window.addEventListener("message", function (event) {
  let data = event.data;
  if (data.type === "apriSceltaLavoro") {
    apriSceltaLavoro();

  }
});

function post(path) {
  fetch(path, {
    method: "POST",
    headers: {
      "Content-Type": "application/json; charset=UTF-8",
    },
    body: JSON.stringify({}),
  }).then((resp) => resp.json());
}

function selectBoscaiolo() {
    post(`https://krs_lavorinowl/boscaiolo`)
  document.querySelector(".titolo").style.display = "none";
  document.querySelector(".lavoro").style.display = "none";
  document.querySelector(".lavoro2").style.display = "none";
  document.querySelector(".lavoro3").style.display = "none";
  document.querySelector(".lavoro4").style.display = "none";
  document.querySelector(".lavoro5").style.display = "none";
  document.querySelector(".bg").style.display = "none";
}
function selectMinatore() {
    post(`https://krs_lavorinowl/minatore`)
  document.querySelector(".titolo").style.display = "none";
  document.querySelector(".lavoro").style.display = "none";
  document.querySelector(".lavoro2").style.display = "none";
  document.querySelector(".lavoro3").style.display = "none";
  document.querySelector(".lavoro4").style.display = "none";
  document.querySelector(".lavoro5").style.display = "none";
  document.querySelector(".bg").style.display = "none";
}
function selectLattaio() {
    post(`https://krs_lavorinowl/lattaio`)
  document.querySelector(".titolo").style.display = "none";
  document.querySelector(".lavoro").style.display = "none";
  document.querySelector(".lavoro2").style.display = "none";
  document.querySelector(".lavoro3").style.display = "none";
  document.querySelector(".lavoro4").style.display = "none";
  document.querySelector(".lavoro5").style.display = "none";
  document.querySelector(".bg").style.display = "none";
}
function selectAgricoltore() {
    post(`https://krs_lavorinowl/agricoltore`)
  document.querySelector(".titolo").style.display = "none";
  document.querySelector(".lavoro").style.display = "none";
  document.querySelector(".lavoro2").style.display = "none";
  document.querySelector(".lavoro3").style.display = "none";
  document.querySelector(".lavoro4").style.display = "none";
  document.querySelector(".lavoro5").style.display = "none";
  document.querySelector(".bg").style.display = "none";
}
function selectFineLavoro() {
  post(`https://krs_lavorinowl/fine`)
  document.querySelector(".titolo").style.display = "none";
  document.querySelector(".lavoro").style.display = "none";
  document.querySelector(".lavoro2").style.display = "none";
  document.querySelector(".lavoro3").style.display = "none";
  document.querySelector(".lavoro4").style.display = "none";
  document.querySelector(".lavoro5").style.display = "none";
  document.querySelector(".bg").style.display = "none";
}

//Funzione Chiudi
document.onkeydown = function (evt) {
  evt = evt || window.event;
  var isEscape = false;
  if ("key" in evt) {
    isEscape = evt.key === "Escape" || evt.key === "Esc";
  } else {
    isEscape = evt.keyCode === 27;
  }
  if (isEscape) {
    
    post(`https://${GetParentResourceName()}/chiudi`);
      
    document.querySelector(".titolo").style.display = "none";
    document.querySelector(".lavoro").style.display = "none";
    document.querySelector(".lavoro2").style.display = "none";
    document.querySelector(".lavoro3").style.display = "none";
    document.querySelector(".lavoro4").style.display = "none";
    document.querySelector(".lavoro5").style.display = "none";
    document.querySelector(".bg").style.display = "none";
  }
};
