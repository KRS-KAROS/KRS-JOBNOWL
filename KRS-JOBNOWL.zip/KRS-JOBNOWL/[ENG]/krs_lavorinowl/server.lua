ESX = exports["es_extended"]:getSharedObject()


-- BOSCAIOLO -- 
RegisterServerEvent('krs_boscaiolo')
AddEventHandler('krs_boscaiolo', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local ped = GetPlayerPed(source)
    local tronco = xPlayer.getInventoryItem(KRS.Item[1]).count 
    if tronco >= 100 then
        xPlayer.showNotification(KRS.Lang["boscaioloraccolta1"])
    else
        xPlayer.addInventoryItem(KRS.Item[1], 3) 
        xPlayer.showNotification(KRS.Lang["boscaioloraccolta2"])
    end
end)

RegisterServerEvent('krs_processoboscaiolo')
AddEventHandler('krs_processoboscaiolo', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local troncoprocessato = xPlayer.getInventoryItem(KRS.Item[1]).count 
    if troncoprocessato < 3 then
        xPlayer.showNotification(KRS.Lang["boscaioloprocesso1"])
    else
        xPlayer.addInventoryItem(KRS.Item[2], 1) 
        xPlayer.removeInventoryItem(KRS.Item[1], 3) 
        xPlayer.showNotification(KRS.Lang["boscaioloprocesso2"])
    end
end)
-- FINE BOSCAIOLO --

-- INIZIO MINATORE -- 
RegisterServerEvent('krs_minatore')
AddEventHandler('krs_minatore', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local ped = GetPlayerPed(source)
    local roccia = xPlayer.getInventoryItem(KRS.Item[3]).count 
    if roccia >= 100 then
        xPlayer.showNotification(KRS.Lang["minatoreraccolta1"])
    else
        xPlayer.addInventoryItem(KRS.Item[3], 1) 
        xPlayer.showNotification(KRS.Lang["minatoreraccolta2"])
    end
end)

RegisterServerEvent('krs_processominatore')
AddEventHandler('krs_processominatore', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local rocciaprocessata = xPlayer.getInventoryItem(KRS.Item[3]).count 
    if rocciaprocessata < 3 then
        xPlayer.showNotification(KRS.Lang["minatoreprocesso1"])
    else
        xPlayer.addInventoryItem(KRS.Item[4], 1) 
        xPlayer.removeInventoryItem(KRS.Item[3], 3) 
        xPlayer.showNotification(KRS.Lang["minatoreprocesso2"])
    end
end)

-- FINE MINATORE --

-- INIZIO LATTAROLO -- 
RegisterServerEvent('krs_mungimucca')
AddEventHandler('krs_mungimucca', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local ped = GetPlayerPed(source)
    local latte = xPlayer.getInventoryItem(KRS.Item[5]).count 
    if latte >= 100 then
        xPlayer.showNotification(KRS.Lang["lattaioraccolta1"])
    else
        xPlayer.addInventoryItem(KRS.Item[5], 1) 
        xPlayer.showNotification(KRS.Lang["lattaioraccolta2"])
    end
end)

RegisterServerEvent('krs_processolatte')
AddEventHandler('krs_processolatte', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local latteprocessato = xPlayer.getInventoryItem(KRS.Item[5]).count 

    if latteprocessato >= 3 then
        xPlayer.removeInventoryItem(KRS.Item[5], 3) 
        xPlayer.addInventoryItem(KRS.Item[6], 1) 
        xPlayer.showNotification(KRS.Lang["lattaioprocesso1"])
    else
        xPlayer.showNotification(KRS.Lang["lattaioprocesso2"])
    end
end)


-- FINE LATTAROLO -- 

-- INIZIO AGRICOLTORE ARANCE --
RegisterServerEvent('krs_arance')
AddEventHandler('krs_arance', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local ped = GetPlayerPed(source)
    local arance = xPlayer.getInventoryItem(KRS.Item[7]).count 
    if arance >= 100 then
        xPlayer.showNotification(KRS.Lang["agricoltoreraccolta1"])
    else
        xPlayer.addInventoryItem(KRS.Item[7], 1) 
        xPlayer.showNotification(KRS.Lang["agricoltoreraccolta2"])
    end
end)

RegisterServerEvent('krs_processoagricoltore')
AddEventHandler('krs_processoagricoltore', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local aranceprocessate = xPlayer.getInventoryItem(KRS.Item[7]).count 
    if aranceprocessate < 3 then
        xPlayer.showNotification(KRS.Lang["agricoltoreprocesso1"])
    else
        xPlayer.addInventoryItem(KRS.Item[8], 1) 
        xPlayer.removeInventoryItem(KRS.Item[7], 3) 
        xPlayer.showNotification(KRS.Lang["agricoltoreprocesso2"])
    end
end)

-- FINE PROCESSO ARANCE --