KRS = {}

-- Start Npc JobNoWl --
KRS.NpcLavoroNome = "cs_paper"
KRS.NpcInizioLavoro = vector4(1218.5447, -1267.0995, 35.4234, 90.3310)

KRS.NpcDepositaNome = "a_m_m_fatlatin_01"
KRS.NpcDepositaLavoro = vector4(1212.5935, -1262.5657, 34.2268, 89.8119)


KRS.Item = {
    'troncodilegno',
    'tavoledilegno',
    'roccia',
    'minerale',
    'latte',
    'latte_lavorato',
    'arance',
    'succodifrutta',
}


KRS.DurataProgressLib = 5000

-- Blip Lavoro Mappa --
KRS.CentroImpieghi = {

    {
        lavoropos = vector3(1217.4999, -1267.2311, 36.4223),
        blip = {
            active = true,
            sprite = 525,
            color = 0,
            size = 0.7,
            name = "Centro Impieghi"
        }
    },
}

-- Processo Boscaiolo --
KRS.NpcBoscaioloNome = "s_m_m_autoshop_01"
KRS.NpcBoscaioloPos = vector4(-534.2561, 5292.0796, 73.2855, 203.7481)
KRS.VeicoloBoscaioloNome = 'mule3'
KRS.SpawnVeicoloBoscaiolo = vector3(1212.5074, -1321.8068, 35.2269)

KRS.PosizioniTaglialegna = {

    vector3(-599.2664, 5239.9370, 71.3985),
    vector3(-603.3984, 5243.1323, 71.3743),
    vector3(-643.3388, 5241.7148, 75.1861),
    vector3(-490.6077, 5394.7261, 77.4932),
    vector3(-499.1177, 5400.3740, 75.5312),
    vector3(-503.2186, 5392.1113, 76.1105),
    vector3(-508.8387, 5389.5859, 73.5859),
}

-- Processo Minatore --
KRS.NpcMinatoreNome = "s_m_y_airworker"
KRS.NpcMinatorePos = vector4(2706.9780, 2777.3823, 36.8780, 30.4403)
KRS.VeicoloMinatoreNome = 'tiptruck'
KRS.SpawnVeicoloMinatore = vector3(1192.4711, -1311.0870, 35.0336)

KRS.PosizioniMinatore = {

    vector3(-591.9721, 2076.3845, 131.3660),
    vector3(-590.6595, 2071.8215, 131.4493),
    vector3(-589.7838, 2064.2466, 131.0112),
    vector3(-589.7000, 2060.4258, 130.9340),
    vector3(-588.1402, 2057.6563, 130.5745),
}

-- Processo Lattaio --
KRS.NpcLattaioNome = "cs_old_man2"
KRS.NpcLattaioPos = vector4(2567.4390, 4684.9536, 33.0513, 51.4303)
KRS.VeicoloLattaioNome = 'youga2'
KRS.SpawnVeicoloLattaio = vector3(1214.5543, -1301.4128, 35.2269)
KRS.AnimaliMuccheNome = "a_c_cow"

KRS.PosizioniMucche = {

    vector3(2249.9136, 4871.2568, 40.9216),
    vector3(2247.7158, 4873.0313, 40.8727),
    vector3(2246.3906, 4874.8672, 40.8782),
}

-- Processo Agricoltore --
KRS.NpcAgricoltoreNome = "csb_undercover"
KRS.NpcAgricoltorePos = vector4(1088.3177, 6507.3804, 20.0438, 180.8798)
KRS.VeicoloAgricoltoreNome = 'kalahari'
KRS.SpawnVeicoloAgricoltore = vector3(1212.9788, -1322.0203, 35.2269)

KRS.PosizioniArance = {

    vector3(378.8909, 6506.0801, 27.9479),
    vector3(379.0756, 6517.6943, 28.3267),
    vector3(370.6068, 6506.0532, 28.3980),
    vector3(370.6448, 6517.8320, 28.3758),
    vector3(369.9256, 6531.8047, 28.3747),
    vector3(362.4967, 6531.6782, 28.3408),
    vector3(363.3827, 6518.1616, 28.2976),
    vector3(363.4957, 6506.1489, 28.5404),
    vector3(355.9217, 6505.1084, 28.4629),
    vector3(356.0201, 6517.3667, 28.1448),
    vector3(354.2992, 6531.0723, 28.3379),
    vector3(346.3873, 6531.6772, 28.6693),
    vector3(348.1032, 6517.6284, 28.7462),
    vector3(348.2758, 6505.5923, 28.7957),
}


KRS.Boscaiolo = {

    male = {
        arms        = {component_id = 3, texture = 0, drawable = 6},
        torso       = {component_id = 11, texture = 0, drawable = 117},
        undershirt  = {component_id = 8, texture = 0, drawable = 171},
        pants       = {component_id = 4, texture = 2, drawable = 0},
        shoes       = {component_id = 6, texture = 0, drawable = 51},
        bag         = {component_id = 5, texture = 6, drawable = 0},
        accesories  = {component_id = 7, texture = 0, drawable = 0},
        kevlar      = {component_id = 9, texture = 0, drawable = 0},
        badge       = {component_id = 10, texture = 0, drawable = 0},
        hat         = {component_id = 0, texture = 0, drawable = -1},
    },
}

KRS.Minatore = {

    male = {
        arms        = {component_id = 3, texture = 0, drawable = 0},
        torso       = {component_id = 11, texture = 0, drawable = 42},
        undershirt  = {component_id = 8, texture = 0, drawable = 15},
        pants       = {component_id = 4, texture = 2, drawable = 90},
        shoes       = {component_id = 6, texture = 0, drawable = 50},
        bag         = {component_id = 5, texture = 6, drawable = 0},
        accesories  = {component_id = 7, texture = 0, drawable = 0},
        kevlar      = {component_id = 9, texture = 0, drawable = 0},
        badge       = {component_id = 10, texture = 0, drawable = 0},
        hat         = {component_id = 0, texture = 0, drawable = -1},
    },
}


KRS.Mucche = {
    
        male = {
        arms        = {component_id = 3, texture = 0, drawable = 0},
        torso       = {component_id = 11, texture = 0, drawable = 42},
        undershirt  = {component_id = 8, texture = 0, drawable = 15},
        pants       = {component_id = 4, texture = 2, drawable = 90},
        shoes       = {component_id = 6, texture = 0, drawable = 50},
        bag         = {component_id = 5, texture = 6, drawable = 0},
        accesories  = {component_id = 7, texture = 0, drawable = 0},
        kevlar      = {component_id = 9, texture = 0, drawable = 0},
        badge       = {component_id = 10, texture = 0, drawable = 0},
        hat         = {component_id = 0, texture = 0, drawable = -1},

    },
}

KRS.Agricoltore = {

    male = {
        arms        = {component_id = 3, texture = 0, drawable = 0},
        torso       = {component_id = 11, texture = 0, drawable = 42},
        undershirt  = {component_id = 8, texture = 0, drawable = 15},
        pants       = {component_id = 4, texture = 2, drawable = 90},
        shoes       = {component_id = 6, texture = 0, drawable = 50},
        bag         = {component_id = 5, texture = 6, drawable = 0},
        accesories  = {component_id = 7, texture = 0, drawable = 0},
        kevlar      = {component_id = 9, texture = 0, drawable = 0},
        badge       = {component_id = 10, texture = 0, drawable = 0},
        hat         = {component_id = 0, texture = 0, drawable = -1},
    },
}

KRS.IconeOxTarget = {
    -- Icona centro impieghi --
    ["centroimpieghiicona"] = "fa-solid fa-info",
    -- Deposita Veicolo --
    ["depositaveicoloicona"] = "fa-solid fa-car",
    -- Icone boscaiolo --
    ["taglialegnaicona"] = "fa-solid fa-hammer",
    ["processalegnaicona"] = "fa-solid fa-tree",
    -- Icone minatore --
    ["picconarocciaicona"] = "fa-solid fa-hill-rockslide",
    ["processorocciaicona"] = "fa-solid fa-hill-rockslide",
    -- Icone lattaio --
    ["mungimuccaicona"] = "fa-solid fa-cow",
    ["processolatteicona"] = "fa-solid fa-cube",
    -- Icone agricoltore --
    ["prendiaranceicona"] = "fa-solid fa-hand",
    ["processoaranceicona"] = "fa-solid fa-cube",


}

KRS.TestoOxTarget = {

    -- Label inizio lavoro --
    ["iniziolavoro"] = "Trova il tuo primo lavoro",
    -- Deposita Veicolo --
    ["depositaveicolo"] = "Deposita il veicolo",
    -- Label boscaiolo --
    ["taglialegna"] = "Taglia la legna",
    ["processalegna"] = "Processa la legna",
    -- Label minatore --
    ["picconaroccia"] = "Piccona la roccia",
    ["processominatore"] = "Processa la roccia",
    -- Label lattaio --
    ["mungilamucca"] = "Mungi la mucca",
    ["processolatte"] = "Processa la roccia",
    -- Label agricoltore --
    ["raccoltaarance"] = "Raccogli le arance",
    ["processalearance"] = "Processa l'arance",
   
}

KRS.Lang = {
     
    -- Inizio Lavoro notifiche --
    ["boscaiolo"] = "Vai prima al centro per l'impiego",
    ["minatore"] = "Vai prima al centro per l'impiego",
    ["lattaio"] = "Vai prima al centro per l'impiego",
    ["agricoltore"] = "Vai prima al centro per l'impiego",

    -- Spawn Veicoli notifiche --
    ["veicoloboscaiolo"] = "Hai già un veicolo spawnato!",
    ["veicolominatore"] = "Hai già un veicolo spawnato!",
    ["veicololattaio"] = "Hai già un veicolo spawnato!",
    ["veicoloagricoltore"] = "Hai già un veicolo spawnato!",

    -- Posizioni sulla mappa notifiche --
    ["mappaboscaiolo"] = "Raggiungi la falegnameria",
    ["mappaminatore"] = "Raggiungi la miniera",
    ["mappalattaio"] = "Raggiungi la fattoria delle mucche",
    ["mappaagricoltore"] = "Raggiungi la fattoria di arance",

    -- Raccolta / Processo --
    ["boscaioloraccolta1"] = "sei troppo lontano dal tronco!!",
    ["boscaioloraccolta2"] = "Hai tagliato il tronco!!",
    ["boscaioloprocesso1"] = "Non possiedi i tronchi di legno!!",
    ["boscaioloprocesso2"] = "Hai lavorato al tronco!!",

    -- Raccolta / Processo --
    ["minatoreraccolta1"] = "Non puoi picconare in questa zona!!",
    ["minatoreraccolta2"] = "Hai prelevato le roccie dalla cava!!",
    ["minatoreprocesso1"] = "Hai lavorato le roccie",
    ["minatoreprocesso2"] = "Non hai abbastanza roccie da lavorare",

    -- Raccolta / Processo --
    ["lattaioraccolta1"] = "Non puoi mungere!!",
    ["lattaioraccolta2"] = "Hai munto la vacca e attinto il latte!",
    ["lattaioprocesso1"] = "Hai confezionato il latte",
    ["lattaioprocesso2"] = "Non hai abbastanza latte da lavorare",

    -- Raccolta / Processo --
    ["agricoltoreraccolta1"] = "Non puoi raccogliere le arance da qui!!",
    ["agricoltoreraccolta2"] = "Hai raccolto le arance dall'albero!!",
    ["agricoltoreprocesso1"] = "Non possiedi le arance!!",
    ["agricoltoreprocesso2"] = "Hai lavorato le arance, hai fatto un buon succo!!",


}