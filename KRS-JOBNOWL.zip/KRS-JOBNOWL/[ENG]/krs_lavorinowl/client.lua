ESX = exports["es_extended"]:getSharedObject()

-- Funzione Chiudi 
RegisterNUICallback('chiudi', function(data, cb)
   SetNuiFocus(false,false)
    cb('ok')
end)

RegisterNUICallback('fine', function(data, cb)
  CancellaLavoro()
  SetNuiFocus(false,false)
   cb('ok')
end)

-- Funzione Apri 
function apriSceltaLavoro()
    SendNUIMessage({
      type = "apriSceltaLavoro",
     
    })
    SetNuiFocus(true, true)
end

RegisterNUICallback('boscaiolo', function(data, cb)
  Boscaiolo()
   SetNuiFocus(false, false)
     cb('ok')
end)

RegisterNUICallback('minatore', function(data, cb)
  Minatore()
   SetNuiFocus(false, false)
     cb('ok')
end)

RegisterNUICallback('lattaio', function(data, cb)
  Lattaio()
   SetNuiFocus(false, false)
     cb('ok')
end)

RegisterNUICallback('agricoltore', function(data, cb)
  Agricoltore()
   SetNuiFocus(false, false)
     cb('ok')
end)


Citizen.CreateThread(function()
  if not HasModelLoaded(KRS.NpcLavoroNome) then
     RequestModel(KRS.NpcLavoroNome)
     while not HasModelLoaded(KRS.NpcLavoroNome) do
        Citizen.Wait(5)
     end
  end

npc = CreatePed(4, KRS.NpcLavoroNome, KRS.NpcInizioLavoro, false, true)
FreezeEntityPosition(npc, true)
SetEntityInvincible(npc, true)
SetBlockingOfNonTemporaryEvents(npc, true)


local MenuLavoro = {
  {
  
      icon =  KRS.IconeOxTarget["centroimpieghiicona"],
      label = KRS.TestoOxTarget["iniziolavoro"],
      onSelect = function(data)
        apriSceltaLavoro()
        SetNuiFocus(true, true)
          
          lib.requestAnimDict('oddjobs@assassinate@vice@hooker')
          TaskPlayAnim(PlayerPedId(), "oddjobs@assassinate@vice@hooker", "argue_a", 1.0, -1.0, 3000, 0, 1, true, true, true)
        
      end,
      canInteract = function(entity, distance, coords, name, bone)
          return not IsEntityDead(entity)
      end
  }
}
exports.ox_target:addLocalEntity(npc, MenuLavoro)
end)



Citizen.CreateThread(function()
    if not HasModelLoaded(KRS.NpcDepositaNome) then
       RequestModel(KRS.NpcDepositaNome)
       while not HasModelLoaded(KRS.NpcDepositaNome) do
          Citizen.Wait(5)
       end
    end
  
  npc = CreatePed(4, KRS.NpcDepositaNome, KRS.NpcDepositaLavoro, false, true)
  FreezeEntityPosition(npc, true)
  SetEntityInvincible(npc, true)
  SetBlockingOfNonTemporaryEvents(npc, true)
  
  
  local MenuDeposita = {
    {
    
        icon =  KRS.IconeOxTarget["depositaveicoloicona"],
        label = KRS.TestoOxTarget["depositaveicolo"],
        onSelect = function(data)
            ESX.Game.DeleteVehicle(Vehicle)
        end,
        canInteract = function(entity, distance, coords, name, bone)
            return not IsEntityDead(entity)
        end
    }
  }
  exports.ox_target:addLocalEntity(npc, MenuDeposita)
  end)



    
    
    
-- OX RACCOLTA LEGNA -- 
CreateThread(function()
  for i = 1, #KRS.PosizioniTaglialegna,1 do 
  exports.ox_target:addBoxZone({
      coords = KRS.PosizioniTaglialegna[i],
      size = vec3(2, 2, 2),
      rotation = 45,
      debug = drawZones,
      options = {
          {
             icon = KRS.IconeOxTarget["taglialegnaicona"],
             label = KRS.TestoOxTarget["taglialegna"],
             onSelect = function(data)
              if boscaiolo then
               ascia = CreateObject(GetHashKey('prop_w_me_hatchet'), 0, 0, 0, true, true, true)
               AttachEntityToEntity(ascia, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 57005), 0.15, -0.02, -0.02, 350.0, 100.00, 280.0, true, true, false, true, 1, true)
               FreezeEntityPosition(PlayerPedId(), true)
               RequestAnimDict("amb@world_human_hammering@male@base")
                while (not HasAnimDictLoaded("amb@world_human_hammering@male@base")) do Citizen.Wait(0) end
                TaskPlayAnim(PlayerPedId(),"amb@world_human_hammering@male@base","base",8.0, 8.0, -1, 80, 0, 0, 0, 0)
                  FreezeEntityPosition(PlayerPedId(), true)
                  if lib.progressCircle({
                      duration = KRS.DurataProgressLib,
                      position = 'bottom',
                      useWhileDead = false,
                      canCancel = true,
                      disable = {
                          car = true,
                      },
                  }) then end
                  Citizen.Wait(3000)
                  DeleteEntity(ascia)
                  ClearPedTasks(PlayerPedId())						
                  FreezeEntityPosition(PlayerPedId(), false)
                  TriggerServerEvent('krs_boscaiolo')
                  
              else
                ESX.ShowNotification(KRS.Lang["boscaiolo"])
                  end
             end,
          }
      }
  })
  end
end)


-- PROCESSO DEL TAGLIALEGNA --
Citizen.CreateThread(function()
  if not HasModelLoaded(KRS.NpcBoscaioloNome) then
     RequestModel(KRS.NpcBoscaioloNome)
     while not HasModelLoaded(KRS.NpcBoscaioloNome) do
        Citizen.Wait(5)
     end
  end
npc = CreatePed(4, KRS.NpcBoscaioloNome, KRS.NpcBoscaioloPos, false, true)
FreezeEntityPosition(npc, true)
SetEntityInvincible(npc, true)
SetBlockingOfNonTemporaryEvents(npc, true)

local ProcessoTaglialegna = {
  {  
      icon =  KRS.IconeOxTarget["processalegnaicona"],
      label = KRS.TestoOxTarget["processalegna"],
      onSelect = function(data)
          if boscaiolo then
              FreezeEntityPosition(PlayerPedId(), true)
          if lib.progressCircle({
              duration = KRS.DurataProgressLib,
              position = 'bottom',
              useWhileDead = false,
              canCancel = true,
              disable = {
                  car = true,
              },
              anim = {
                  dict = 'anim@heists@box_carry@',
                  clip = 'idle' 
              },
              prop = {
                  model = 'prop_fncwood_16e',
                  bone = 60309,
                  pos = vec3(0.025, 0.08, 0.255),
                  rot = vec3(-145.0, 290.0, 0.0)
              },
          }) then end

          Citizen.Wait(3000)
          
              ClearPedTasks(PlayerPedId())						
              FreezeEntityPosition(PlayerPedId(), false)
              TriggerServerEvent('krs_processoboscaiolo')
             
              else
                ESX.ShowNotification(KRS.Lang["boscaiolo"])
              end
      end,
      canInteract = function(entity, distance, coords, name, bone)
          return not IsEntityDead(entity)
      end
  }
}

exports.ox_target:addLocalEntity(npc, ProcessoTaglialegna)
end)


-- OX RACCOLTA ROCCE -- 
CreateThread(function()
  for i = 1, #KRS.PosizioniMinatore,1 do 
  exports.ox_target:addBoxZone({
      coords = KRS.PosizioniMinatore[i],
      size = vec3(2, 2, 2),
      rotation = 45,
      debug = drawZones,
      options = {
          {
             icon = KRS.IconeOxTarget["picconarocciaicona"], 
             label = KRS.TestoOxTarget["picconaroccia"], 
             onSelect = function(data)
              if minatore then
                  piccone = CreateObject(GetHashKey('prop_tool_pickaxe'), 0, 0, 0, true, true, true)
                  AttachEntityToEntity(piccone, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 57005), 0.15, -0.02, -0.02, 350.0, 100.00, 280.0, true, true, false, true, 1, true)
                  FreezeEntityPosition(PlayerPedId(), true)
                  RequestAnimDict("amb@world_human_hammering@male@base")
                  while (not HasAnimDictLoaded("amb@world_human_hammering@male@base")) do Citizen.Wait(0) end
                  TaskPlayAnim(PlayerPedId(),"amb@world_human_hammering@male@base","base",8.0, 8.0, -1, 80, 0, 0, 0, 0)
                  if lib.progressCircle({
                      duration = KRS.DurataProgressLib,
                      position = 'bottom',
                      useWhileDead = false,
                      canCancel = true,
                      disable = {
                          car = true,
                      },
                  }) then end
                  Citizen.Wait(3000)
                  DeleteEntity(piccone)
                  ClearPedTasks(PlayerPedId())
                  FreezeEntityPosition(PlayerPedId(), false)
                  TriggerServerEvent('krs_minatore')
                 
                  else
                    ESX.ShowNotification(KRS.Lang["minatore"])
                  end
             end,
          }
      }
  })
  end
end)


-- PROCESSO DEL MINATORE --
Citizen.CreateThread(function()
  if not HasModelLoaded(KRS.NpcMinatoreNome) then
     RequestModel(KRS.NpcMinatoreNome)
     while not HasModelLoaded(KRS.NpcMinatoreNome) do
        Citizen.Wait(5)
     end
end
npc = CreatePed(4, KRS.NpcMinatoreNome, KRS.NpcMinatorePos, false, true)
FreezeEntityPosition(npc, true)
SetEntityInvincible(npc, true)
SetBlockingOfNonTemporaryEvents(npc, true)

local ProcessoMinatore = {
  {  
      icon = KRS.IconeOxTarget["processorocciaicona"],
      label = KRS.TestoOxTarget["processominatore"],
      onSelect = function(data)
          if minatore then
              FreezeEntityPosition(PlayerPedId(), true)
          if lib.progressCircle({
              duration = KRS.DurataProgressLib,
              position = 'bottom',
              useWhileDead = false,
              canCancel = true,
              disable = {
                  car = true,
              },
              anim = {
                  dict = 'anim@heists@box_carry@',
                  clip = 'idle' 
              },
              prop = {
                  model = 'prop_rock_5_e',
                  bone = 60309,
                  pos = vec3(0.025, 0.08, 0.255),
                  rot = vec3(-145.0, 290.0, 0.0)
              },
          }) then end

          Citizen.Wait(3000)
          
              ClearPedTasks(PlayerPedId())						
              FreezeEntityPosition(PlayerPedId(), false)
              TriggerServerEvent('krs_processominatore')
              
              else
                ESX.ShowNotification(KRS.Lang["minatore"])
              end
      end,
      canInteract = function(entity, distance, coords, name, bone)
          return not IsEntityDead(entity)
      end
  }
}
exports.ox_target:addLocalEntity(npc, ProcessoMinatore)
end)




CreateThread(function()
  for i = 1, #KRS.PosizioniMucche,1 do 
  exports.ox_target:addBoxZone({
      coords = KRS.PosizioniMucche[i],
      size = vec3(2, 2, 2),
      rotation = 45,
      debug = drawZones,
          options = {
              {
              icon = KRS.IconeOxTarget["mungimuccaicona"],
              label = KRS.TestoOxTarget["mungilamucca"],
              onSelect = function(data)
                  if lattaio then
                      
                      FreezeEntityPosition(PlayerPedId(), true)
                      if lib.progressCircle({
                          duration = KRS.DurataProgressLib,
                          position = 'bottom',
                          useWhileDead = false,
                          canCancel = true,
                          disable = {
                              car = true,
                          },
                          anim = {
                              dict = 'mini@repair',
                              clip = 'fixing_a_ped' 
                          },
                      }) then end
                      Citizen.Wait(3000)
                      ClearPedTasks(PlayerPedId())
                      FreezeEntityPosition(PlayerPedId(), false)
                      TriggerServerEvent('krs_mungimucca')
                   
                      else
                        ESX.ShowNotification(KRS.Lang["lattaio"])
                    end
              end,
              }
          }
      })
  end
end)

-- MUCCHE --
Citizen.CreateThread(function()
  RequestModel(GetHashKey(KRS.AnimaliMuccheNome))
  while not HasModelLoaded(GetHashKey(KRS.AnimaliMuccheNome)) do
      Wait(155)
  end
  local mucca =  CreatePed(4, GetHashKey(KRS.AnimaliMuccheNome), 2245.8364, 4875.2241, 39.8686, 315.1719, false, true)
  FreezeEntityPosition(mucca, true)
  SetEntityInvincible(mucca, true)
  SetBlockingOfNonTemporaryEvents(mucca, true)
  while true do
      Citizen.Wait(10000)
      TaskPedSlideToCoord(mucca, 2245.8364, 4875.2241, 39.8686, 315.1719, 10)
  end
end)

Citizen.CreateThread(function()
  RequestModel(GetHashKey(KRS.AnimaliMuccheNome))
  while not HasModelLoaded(GetHashKey(KRS.AnimaliMuccheNome)) do
      Wait(155)
  end
  local mucca =  CreatePed(4, GetHashKey(KRS.AnimaliMuccheNome), 2247.2163, 4873.4536, 39.8599, 313.5623, false, true)
  FreezeEntityPosition(mucca, true)
  SetEntityInvincible(mucca, true)
  SetBlockingOfNonTemporaryEvents(mucca, true)
  while true do
      Citizen.Wait(10000)
      TaskPedSlideToCoord(mucca, 2247.2163, 4873.4536, 39.8599, 313.5623, 10)
  end
end)
Citizen.CreateThread(function()
      RequestModel(GetHashKey(KRS.AnimaliMuccheNome))
      while not HasModelLoaded(GetHashKey(KRS.AnimaliMuccheNome)) do
          Wait(155)
      end
      local mucca =  CreatePed(4, GetHashKey(KRS.AnimaliMuccheNome), 2249.0244, 4871.9346, 39.9139, 321.7546, false, true)
      FreezeEntityPosition(mucca, true)
      SetEntityInvincible(mucca, true)
      SetBlockingOfNonTemporaryEvents(mucca, true)
      while true do
          Citizen.Wait(10000)
          TaskPedSlideToCoord(mucca, 2249.0244, 4871.9346, 39.9139, 321.7546, 10)
    end
end)


-- PROCESSO DEL LATTE --
Citizen.CreateThread(function()
  if not HasModelLoaded(KRS.NpcLattaioNome) then
     RequestModel(KRS.NpcLattaioNome)
     while not HasModelLoaded(KRS.NpcLattaioNome) do
        Citizen.Wait(5)
     end
  end
npc = CreatePed(4, KRS.NpcLattaioNome, KRS.NpcLattaioPos, false, true)
FreezeEntityPosition(npc, true)
SetEntityInvincible(npc, true)
SetBlockingOfNonTemporaryEvents(npc, true)

local ProcessoLatte = {
  {  
      icon = KRS.IconeOxTarget["processolatteicona"],
      label = KRS.TestoOxTarget["processolatte"],
      onSelect = function(data)
          if lattaio then
              
              FreezeEntityPosition(PlayerPedId(), true)
              if lib.progressCircle({
                  duration = KRS.DurataProgressLib,
                  position = 'bottom',
                  useWhileDead = false,
                  canCancel = true,
                  disable = {
                      car = true,
                  },
                  anim = {
                      dict = 'anim@heists@box_carry@',
                      clip = 'idle' 
                  },
                  prop = {
                      model = 'hei_prop_heist_box',
                      bone = 60309,
                      pos = vec3(0.025, 0.08, 0.255),
                      rot = vec3(-145.0, 290.0, 0.0)
                  },
              }) then end
              Citizen.Wait(3000)
              ClearPedTasks(PlayerPedId())
              FreezeEntityPosition(PlayerPedId(), false)
              TriggerServerEvent('krs_processolatte')
              
              else
                ESX.ShowNotification(KRS.Lang["lattaio"])
              end
      end,
      canInteract = function(entity, distance, coords, name, bone)
          return not IsEntityDead(entity)
      end
  }
}

exports.ox_target:addLocalEntity(npc, ProcessoLatte)
end)


-- OX DELLA RACCOLTA ARANCE --
CreateThread(function()
  for i = 1, #KRS.PosizioniArance,1 do 
  exports.ox_target:addBoxZone({
      coords = KRS.PosizioniArance[i],
      size = vec3(2, 2, 2),
      rotation = 45,
      debug = drawZones,
      options = {
          {
             icon = KRS.IconeOxTarget["prendiaranceicona"],
             label = KRS.TestoOxTarget["raccoltaarance"],
             onSelect = function(data)
              if agricoltore then
                  
                  FreezeEntityPosition(PlayerPedId(), true)
                  if lib.progressCircle({
                      duration = KRS.DurataProgressLib,
                      position = 'bottom',
                      useWhileDead = false,
                      canCancel = true,
                      disable = {
                          car = true,
                      },
                      anim = {
                          dict = 'amb@prop_human_movie_bulb@idle_a',
                          clip = 'idle_a' 
                      },
                  }) then end
                Citizen.Wait(3000)
                ClearPedTasks(PlayerPedId())						
                FreezeEntityPosition(PlayerPedId(), false)
                  TriggerServerEvent('krs_arance')
                  
                  else
                    ESX.ShowNotification(KRS.Lang["agricoltore"])
                  end
             end,
          }
      }
  })
  end
  end)
  
  -- GRID DEL PROCESSO ARANCE -- 
  Citizen.CreateThread(function()
      if not HasModelLoaded(KRS.NpcAgricoltoreNome) then
         RequestModel(KRS.NpcAgricoltoreNome)
         while not HasModelLoaded(KRS.NpcAgricoltoreNome) do
            Citizen.Wait(5)
         end
      end
  npc = CreatePed(4, KRS.NpcAgricoltoreNome, KRS.NpcAgricoltorePos, false, true)
  FreezeEntityPosition(npc, true)
  SetEntityInvincible(npc, true)
  SetBlockingOfNonTemporaryEvents(npc, true)
  
  local ProcessoArance = {
      {  
          icon = KRS.IconeOxTarget["processoaranceicona"],
          label = KRS.TestoOxTarget["processalearance"],
          onSelect = function(data)
              if agricoltore then
                  FreezeEntityPosition(PlayerPedId(), true)
              if lib.progressCircle({
                  duration = KRS.DurataProgressLib,
                  position = 'bottom',
                  useWhileDead = false,
                  canCancel = true,
                  disable = {
                      car = true,
                  },
                  anim = {
                      dict = 'anim@heists@box_carry@',
                      clip = 'idle' 
                  },
                  prop = {
                      model = 'hei_prop_heist_box',
                      bone = 60309,
                      pos = vec3(0.025, 0.08, 0.255),
                      rot = vec3(-145.0, 290.0, 0.0)
                  },
              }) then end
   
              Citizen.Wait(3000)
                ClearPedTasks(PlayerPedId())						
                FreezeEntityPosition(PlayerPedId(), false)
                  TriggerServerEvent('krs_processoagricoltore')
                 
                  else
                    ESX.ShowNotification(KRS.Lang["agricoltore"])
                  end
          end,
          canInteract = function(entity, distance, coords, name, bone)
              return not IsEntityDead(entity)
          end
      }
  }
  exports.ox_target:addLocalEntity(npc, ProcessoArance)
end)


-- BLIP CENTRO IMPIEGHI --
CreateThread(function()
  for i = 1, #KRS.CentroImpieghi, 1 do
      local KRS = KRS.CentroImpieghi[i]

      if KRS.blip.active then 
    local blip = AddBlipForCoord(KRS.lavoropos.x, KRS.lavoropos.y, KRS.lavoropos.z)
    SetBlipSprite (blip, KRS.blip.sprite)
    SetBlipDisplay(blip, 4)
    SetBlipScale  (blip, KRS.blip.size)
    SetBlipColour (blip, KRS.blip.color)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(KRS.blip.name)
    EndTextCommandSetBlipName(blip)
      end
  end
end)


-- ANNULLA LAVORO --    
 CancellaLavoro = function()
    boscaiolo = false
    minatore = false
    lattaio = false
    agricoltore = false
    -- Rimuove il blip dei lavori --
    RemoveBlip(boscaioloraccoltablip)
    RemoveBlip(boscaioloprocessoblip)

    RemoveBlip(minatoreraccoltablip)
    RemoveBlip(minatoreprocessoblip)

    RemoveBlip(lattaioraccoltablip)
    RemoveBlip(lattaioprocessoblip)

    RemoveBlip(agricoltoreraccoltablip)
    RemoveBlip(agricoltoreprocessoblip)

    -- Rimuove il punto dei lavori --
    DeleteWaypoint(puntoboscaiolo)
    DeleteWaypoint(puntominatore)
    DeleteWaypoint(puntolattaio)
    DeleteWaypoint(puntoagricoltore)
end
-- FINE ANNULLA LAVORO

-- INIZIO BOSCAIOLO -- 
local veicoloBoscaiolo = false
function Boscaiolo()
    if not veicoloBoscaiolo then
        veicoloBoscaiolo = true
        if lib.progressCircle({
            duration = KRS.DurataProgressLib,
            position = 'bottom',
            useWhileDead = false,
            canCancel = true,
            disable = {
                car = true,
            },
            anim = {
                dict = 'missmic4',
                clip = 'michael_tux_fidget'
            },
        }) then
            exports['fivem-appearance']:setPedComponents(cache.ped, {KRS.Boscaiolo.male.torso,KRS.Boscaiolo.male.undershirt,KRS.Boscaiolo.male.pants,KRS.Boscaiolo.male.shoes,KRS.Boscaiolo.male.bag,KRS.Boscaiolo.male.accesories,KRS.Boscaiolo.male.kevlar,KRS.Boscaiolo.male.badge,KRS.Boscaiolo.male.arms})  
            exports['fivem-appearance']:setPedProps(cache.ped, {KRS.Boscaiolo.male.hat})    
            Wait(2000)
            
            boscaiolo = true
            ESX.Game.SpawnVehicle(KRS.VeicoloBoscaioloNome, KRS.SpawnVeicoloBoscaiolo, 82.9710, function(v)
                SetPedIntoVehicle(PlayerPedId(), v, -1)
                Vehicle = v
            end)
            ESX.ShowNotification(KRS.Lang["mappaboscaiolo"])
            puntoboscaiolo = SetNewWaypoint(-497.3575, 5392.8608, 76.8859)
            boscaioloraccoltablip = AddBlipForCoord(-497.3575, 5392.8608, 76.8859)
            SetBlipSprite(boscaioloraccoltablip, 211)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Falegnameria")
            EndTextCommandSetBlipName(boscaioloraccoltablip)
            boscaioloprocessoblip = AddBlipForCoord(-534.2561, 5292.0796, 74.2855)
            SetBlipSprite(boscaioloprocessoblip, 478)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Processo falegnameria")
            EndTextCommandSetBlipName(boscaioloprocessoblip)
        end
        
    else
        ESX.ShowNotification(KRS.Lang["veicoloboscaiolo"])
    end
end

function AnnullaLavoroBoscaiolo()
    boscaiolo = false
    veicoloBoscaiolo = false
end
-- FINE BOSCAIOLO --


-- INIZIO MINATORE -- 
local veicoloMinatore = false
function Minatore()
    if not veicoloMinatore then
        veicoloMinatore = true
        if lib.progressCircle({
            duration = KRS.DurataProgressLib,
            position = 'bottom',
            useWhileDead = false,
            canCancel = true,
            disable = {
                car = true,
            },
            anim = {
                dict = 'missmic4',
                clip = 'michael_tux_fidget'
            },
        }) then
            exports['fivem-appearance']:setPedComponents(cache.ped, {KRS.Minatore.male.torso,KRS.Minatore.male.undershirt,KRS.Minatore.male.pants,KRS.Minatore.male.shoes,KRS.Minatore.male.bag,KRS.Minatore.male.accesories,KRS.Minatore.male.kevlar,KRS.Minatore.male.badge,KRS.Minatore.male.arms})  
            exports['fivem-appearance']:setPedProps(cache.ped, {KRS.Minatore.male.hat})    
            Wait(2000)
            
            minatore = true
            ESX.Game.SpawnVehicle(KRS.VeicoloMinatoreNome, KRS.SpawnVeicoloMinatore, 268.6332, function(v)
                SetPedIntoVehicle(PlayerPedId(), v, -1)
                Vehicle = v
            end)
            ESX.ShowNotification(KRS.Lang["mappaminatore"])
            puntominatore = SetNewWaypoint(-607.6548, 2109.9001, 126.7562)
            minatoreraccoltablip = AddBlipForCoord(-607.6548, 2109.9001, 126.7562)
            SetBlipSprite(minatoreraccoltablip, 124)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Miniera")
            EndTextCommandSetBlipName(minatoreraccoltablip)
            minatoreprocessoblip = AddBlipForCoord(2706.9780, 2777.3823, 37.8780)
            SetBlipSprite(minatoreprocessoblip, 501)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Processo miniera")
            EndTextCommandSetBlipName(minatoreprocessoblip)
        end
     
    else
        ESX.ShowNotification(KRS.Lang["veicolominatore"])
    end
end

function AnnullaLavoroMinatore()
    minatore = false
    veicoloMinatore = false
end
-- FINE MINATORE -- 

-- MUNGI MUCCA --
local veicoloMucche = false
function Lattaio()
    if not veicoloMucche then
        veicoloMucche = true
        if lib.progressCircle({
            duration = KRS.DurataProgressLib,
            position = 'bottom',
            useWhileDead = false,
            canCancel = true,
            disable = {
                car = true,
            },
            anim = {
                dict = 'missmic4',
                clip = 'michael_tux_fidget'
            },
        }) then
            exports['fivem-appearance']:setPedComponents(cache.ped, {KRS.Mucche.male.torso,KRS.Mucche.male.undershirt,KRS.Mucche.male.pants,KRS.Mucche.male.shoes,KRS.Mucche.male.bag,KRS.Mucche.male.accesories,KRS.Mucche.male.kevlar,KRS.Mucche.male.badge,KRS.Mucche.male.arms})  
            exports['fivem-appearance']:setPedProps(cache.ped, {KRS.Mucche.male.hat})     
            Wait(2000)
       
            lattaio = true
            ESX.Game.SpawnVehicle(KRS.VeicoloLattaioNome, KRS.SpawnVeicoloLattaio, 93.5989, function(v)
                SetPedIntoVehicle(PlayerPedId(), v, -1)
                Vehicle = v
            end)
            ESX.ShowNotification(KRS.Lang["mappalattaio"])
            puntolattaio = SetNewWaypoint(2254.5874, 4867.2437, 40.8587)
            lattaioraccoltablip = AddBlipForCoord(2254.5874, 4867.2437, 40.8587)
            lattaioprocessoblip = AddBlipForCoord(2567.7395, 4685.0264, 34.0451)
            SetBlipSprite(lattaioraccoltablip, 141)
            SetBlipSprite(lattaioprocessoblip, 478)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Lattaio")
            EndTextCommandSetBlipName(lattaioraccoltablip)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Processo latte")
            EndTextCommandSetBlipName(lattaioprocessoblip)
        end
       
    else
        ESX.ShowNotification(KRS.Lang["veicololattaio"])
    end
end

function AnnullaLavoroLattaio()
    lattaio = false
    veicoloMucche = false
end

-- AGRICOLTORE --
local veicoloAgricoltore = false
function Agricoltore()
    if not veicoloAgricoltore then
        veicoloAgricoltore = true
        if lib.progressCircle({
            duration = KRS.DurataProgressLib,
            position = 'bottom',
            useWhileDead = false,
            canCancel = true,
            disable = {
                car = true,
            },
            anim = {
                dict = 'missmic4',
                clip = 'michael_tux_fidget'
            },
        }) then
            exports['fivem-appearance']:setPedComponents(cache.ped, {KRS.Agricoltore.male.torso,KRS.Agricoltore.male.undershirt,KRS.Agricoltore.male.pants,KRS.Agricoltore.male.shoes,KRS.Agricoltore.male.bag,KRS.Agricoltore.male.accesories,KRS.Agricoltore.male.kevlar,KRS.Agricoltore.male.badge,KRS.Agricoltore.male.arms})  
            exports['fivem-appearance']:setPedProps(cache.ped, {KRS.Agricoltore.male.hat})     
            Wait(2000)
           
            agricoltore = true
            ESX.Game.SpawnVehicle(KRS.VeicoloAgricoltoreNome, KRS.SpawnVeicoloAgricoltore, 83.6452, function(v)
                SetPedIntoVehicle(PlayerPedId(), v, -1)
                Vehicle = v
            end)
            ESX.ShowNotification(KRS.Lang["mappaagricoltore"])
            puntoagricoltore = SetNewWaypoint(370.6554, 6512.4326, 28.3896)
            agricoltoreraccoltablip = AddBlipForCoord(370.6554, 6512.4326, 28.3896)
            agricoltoreprocessoblip = AddBlipForCoord(1088.3177, 6507.3804, 21.0438)
            SetBlipSprite(agricoltoreraccoltablip, 76)
            SetBlipSprite(agricoltoreprocessoblip, 501)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Agricoltore")
            EndTextCommandSetBlipName(agricoltoreraccoltablip)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Processo")
            EndTextCommandSetBlipName(agricoltoreprocessoblip)
        end
       
    else
        ESX.ShowNotification(KRS.Lang["veicoloagricoltore"])
    end
end

function AnnullaLavoroAgricoltore()
    agricoltore = false
    veicoloAgricoltore = false
end